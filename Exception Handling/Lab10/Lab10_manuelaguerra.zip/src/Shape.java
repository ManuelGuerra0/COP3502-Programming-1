
public class Shape {
	String color;
	
	Shape(){}
	
	Shape(String c) {
		color = c;
	}
	
	public String toString(int i) {
		return "";
	}
}
